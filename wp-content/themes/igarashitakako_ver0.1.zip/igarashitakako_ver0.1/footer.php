    <footer id="footer">
      <?php wp_nav_menu( array('menu' => 'global_menu', 'menu_class' => 'global_menu')); ?>
      <div class="clearfix"></div>
      <small>このWeb siteに掲載されている画像や情報は、弊社の仕事紹介を目的としています。画像掲載に関して、不都合がございましたら削除・変更いたしますのでお手数ですがご連絡をいただきますようよろしくお願いいたします。</small>
    </footer>
  </div>
  <?php wp_footer(); ?>

  <script type="text/javascript" src="//webfont.fontplus.jp/accessor/script/fontplus.js?55gB3urzk3w%3D&box=ayuzSDr3dNM%3D&aa=1&ab=2" charset="utf-8"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?php bloginfo(template_url);?>/javascripts/app.js"></script>

  </body>
</html>
