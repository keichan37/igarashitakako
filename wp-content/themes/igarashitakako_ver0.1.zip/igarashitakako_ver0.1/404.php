<?php get_header(); ?>
  <div id="error">
    <div class="container thin-container">
      <div class="page-content">
        <h1>ページが見つかりませんでした</h1>
        <p>あなたがアクセスしようとしたページは削除されたかURLが変更されています。</p>
      </div>
    </div>    
  </div>
<?php get_footer(); ?>
